#!/bin/bash
# Create thumbnail .png files out of front pages of all .pdf files in current directory
# or out of all .pdf files in the directory supplied in argument 1

if [ -z "$1" ]  
then
	pdf_files=$(ls *.pdf)
else
	cd $1
	pdf_files=$(ls *.pdf)
fi

# Use Imagemagick to create the thumbnails for each .pdf file
for file_name in $pdf_files
do
	postfixes=.pdf  # Regexp for valid file name postfix
	stripped_file_name=${file_name%$postfixes}
	convert -compress none -density 200 -gravity center $file_name[0] $stripped_file_name.png
	convert -trim +repage -filter LanczosSharp -interpolate Mesh +distort Resize 200x300 -unsharp 12x6+0.5+0 \
  		$stripped_file_name.png $stripped_file_name.png
  	# convert -bordercolor White -border 5x5 stripped_file_name.png $stripped_file_name.png
done
